filename PED899EC list;

 %put NOTE- ;
 %put NOTE: Data for package rich_kaplan_meier_plot, version 0.1.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-07-06T17:22:11; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(rich_kaplan_meier_plot) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package rich_kaplan_meier_plot, version 0.1.0, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

